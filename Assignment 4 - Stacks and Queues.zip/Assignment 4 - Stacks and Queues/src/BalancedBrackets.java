import java.util.Stack;

public class BalancedBrackets {
    public static String isBalanced(String s) {

        Stack<Character> stack = new Stack<>();

        for (int i = 0; i < s.length(); i++) {

            char bracket = s.charAt(i);

            if (bracket == '(') {

                stack.push(')');

            } else if (bracket == '{') {

                stack.push('}');

            } else if (bracket == '[') {

                stack.push(']');

            } else {

                if (stack.isEmpty()) {

                    return "NO";

                }
                if (stack.pop() != bracket) {

                    return "NO";

                }
            }
        }

        if (stack.isEmpty()) {

            return "YES";

        } else {

            return "NO";

        }
    }


    public static void main(String[] args) {

        System.out.println(isBalanced("{[()]}"));

        System.out.println(isBalanced("{[(])}"));

        System.out.println(isBalanced("{{[[(())]]}}"));

    }
}


