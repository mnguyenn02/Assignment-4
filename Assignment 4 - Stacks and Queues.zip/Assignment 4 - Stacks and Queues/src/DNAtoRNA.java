import java.util.Stack;

public class DNAtoRNA {

    public static String DtoR(String dna) {

        Stack<Character> stack = new Stack<>();
        String rna = "";

        for(int i = 0; i < dna.length(); i++) {

            stack.push(dna.charAt(i));

        }

        while(!stack.isEmpty()) {

            char string = stack.pop();

            if(string == 'T') {

                rna = 'U' + rna;

            } else {

                rna = string + rna;

            }
        }

        return rna;

    }

    public static void main(String[] args) {

        System.out.println(DtoR("AGCTGGGAAACGTAGGCCTA"));

        System.out.println(DtoR("TTTTTTTTTTGGCGCG"));

        System.out.println(DtoR("CTTTGGGACTAGTAACCCATTTCGGCT"));

    }

}
